package ru.tai.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import ru.tai.model.Token;
import ru.tai.servise.TokenAndUserRepository;
import ru.tai.servise.UserRepository;

import javax.annotation.Priority;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.ext.Provider;
import java.io.IOException;


@Controller
@Secured
@Provider
@Priority(Priorities.AUTHENTICATION)
public class AuthFilter implements ContainerRequestFilter {

    private static final Logger log = LoggerFactory.getLogger(AuthFilter.class);

    /**
     *  Внедряем репозиторий пользователей, где будут храниться зарегистрированные пользователи
     */
    @Autowired
    UserRepository userRepository;

    @Autowired
    TokenAndUserRepository tokenAndUserRepository;


    @Override
    public void filter(ContainerRequestContext containerRequestContext) throws IOException {

        String authHeader = containerRequestContext.getHeaderString(HttpHeaders.AUTHORIZATION);

        if (authHeader==null || !authHeader.startsWith("Bearer")){
            log.info("Заголовок не имеет авторизации!!!");
            return;
        }

        // Извлекаеи токен
        String tokenStr = authHeader.substring("Bearer".length()).trim();

        Token token = new Token(Long.parseLong(tokenStr));

//        if (tokenAndUserRepository.containsUser(user))
//        Token token =


    }
}
