package ru.tai.servise;

import org.springframework.stereotype.Service;
import ru.tai.model.Token;
import ru.tai.model.User;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

@Service
public class TokenAndUserRepository {

    private Map<User, Token> tokenAndUserRepo = new HashMap<>();

    public boolean addTokenAndUser(User user, Token token){

        tokenAndUserRepo.put(user, token);
        return true;
    }

    public boolean containsUser(User user){

        if (tokenAndUserRepo.containsKey(user))return true;
        return false;
    }

    public Token getTokenByUser(User user){
        if (tokenAndUserRepo.containsKey(user)){
            for (Map.Entry<User, Token> entry : tokenAndUserRepo.entrySet()) {
                if (entry.getKey().equals(user)){
                    return entry.getValue();
                }
            }
        }
        return null;
    }
}
