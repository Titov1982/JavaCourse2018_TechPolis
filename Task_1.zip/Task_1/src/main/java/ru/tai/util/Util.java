package ru.tai.util;

import ru.tai.model.Token;
import ru.tai.model.User;

import java.util.Random;

public class Util {

    public static Token requestToken(User user){
        final Random defaultToken = new Random(1_000_000_000 + user.hashCode());
        Token token = new Token(defaultToken.nextLong());
        return token;
    }
}
