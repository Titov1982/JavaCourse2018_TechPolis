package ru.tai.config;

import org.glassfish.jersey.server.ResourceConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import ru.tai.controllers.AuthController;
import ru.tai.controllers.AuthFilter;

import javax.ws.rs.ApplicationPath;
import java.util.ArrayList;
import java.util.List;

@Configuration
//@ApplicationPath(value = "/api")
public class JerseyConfig extends ResourceConfig {

    private static final Logger log = LoggerFactory.getLogger(AuthController.class);

    List<String> registeredControllersName = new ArrayList<>();

    public JerseyConfig() {

        register(AuthFilter.class);
        register(AuthController.class);

        registeredControllersName.add(AuthFilter.class.getName());
        registeredControllersName.add(AuthController.class.getName());

        for (String className: registeredControllersName){
            log.info("Registered Jersey controller: " + className);
        }


    }

}