import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;


/**
 * Контроллер авторизации
 *
 * Реализуем методы:
 *
 *  1. register
 *  2. login
 *  3. logout
 *
 */

@Controller
@RequestMapping("/")
public class TempAuthController {

    private static final Logger log = LoggerFactory.getLogger(TempAuthController.class);

//    public AuthController() {
//        log.info("Create controller AuthController!!!");
//    }

    @RequestMapping(
            path = "register",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<String> register(@RequestParam("name") String name, @RequestParam("password") String password){

        log.info("Method register: name= " + name + " pass= " + password);

//        return ResponseEntity.ok().build();
        return ResponseEntity.ok("Method register: name= " + name + " pass= " + password);
    }

    @RequestMapping(
            path = "login",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<String> login(@RequestParam("name") String name, @RequestParam("password") String password){

        log.info("Method login: name= " + name + " pass= " + password);

//        return ResponseEntity.ok().build();
        return ResponseEntity.ok("Method register: name= " + name + " pass= " + password);
    }

    @RequestMapping(
            path = "test",
            method = RequestMethod.GET,
            consumes = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity test(){

        log.info("Hello from test method :)");

        return ResponseEntity.ok("Hello from test method :)");
    }

}
